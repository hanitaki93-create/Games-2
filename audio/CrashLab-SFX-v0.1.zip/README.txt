CRASH LAB SOUND LAB - 24 original synth WAV effects, CC0-1.0. For audition only; not integrated into Unity.
